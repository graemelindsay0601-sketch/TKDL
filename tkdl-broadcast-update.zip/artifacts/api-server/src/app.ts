import express, { type Express } from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import path from "path";
import pinoHttp from "pino-http";
import session from "express-session";
import connectPg from "connect-pg-simple";
import router from "./routes";
import { logger } from "./lib/logger";
import cacheMiddleware from "./middleware/cache";
import { seedAchievements } from "./lib/achievements";
import { maybeAutoResetLeagueSeasons, initializeSeasonResetScheduler } from "./lib/seasonReset";
import { addPerformanceIndexes } from "./db/migrations/add_performance_indexes";
import { seedTourSystem } from "./lib/tourSeed";
import { seedNotificationTables, initializeNotificationPreferences } from "./lib/notificationsMigration";
import { initializeCardTables, initializeFeatureFlags, initializeFeaturedCardShopTables } from "./lib/cardTablesMigration";
import { addFavoritesColumn } from "./db/migrations/add_favorites";
import { addAchievementRewards } from "./db/migrations/add_achievement_rewards";
import { addAchievementSeasonColumn } from "./db/migrations/add_achievement_season_column";
import { addSeasonLeagueType } from "./db/migrations/add_season_league_type";
import { createCardClashPlayerSettingsTable } from "./db/migrations/create_card_clash_player_settings";
import { up as createCardClashFavoritesTable } from "./db/migrations/add_card_clash_favorites";
import { addDailyChallengeKeyColumn } from "./db/migrations/add_daily_challenge_key";
import { addLongestLossStreakColumn } from "./db/migrations/add_longest_loss_streak";
import { addCareerBiggestPointsFallColumn } from "./db/migrations/add_career_biggest_points_fall";
import { addTkdlLiveBroadcastTables } from "./db/migrations/add_tkdl_live_broadcast";
import { seedBroadcastSettings } from "./broadcast/config";
import { seedCardDefinitions } from "./services/card-definitions-service";
import { challengeService } from "./services/challenge-service";
import { initializeCoachTipsScheduler } from "./services/coachTipsScheduler";
import { initializeFeaturedCardScheduler } from "./services/featured-card-shop-service";
import webpush from "web-push";
import { seedTitles, sweepAllPlayerTitles } from "./lib/titles";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { playersTable, seasonsTable, matchesTable, seasonStandingsTable, settingsTable, gameTypesTable, usersTable } from "@workspace/db";
import { eq, count, sql } from "drizzle-orm";

// Configure VAPID keys for push notifications
if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(
    "mailto:support@tkdl.local",
    process.env.VAPID_PUBLIC_KEY,
    process.env.VAPID_PRIVATE_KEY
  );
  logger.info("Push notification VAPID keys configured");
} else {
  logger.warn("VAPID keys not configured - push notifications will not work");
}

// Every admin-only action in the app (from the /admin page and every Card
// Clash/challenges/playoff admin panel) is now gated by ONE check: the
// session flag set by POST /admin/verify-pin in routes/admin.ts, which
// compares against ADMIN_PIN. If that env var isn't set on the server, it
// silently falls back to a default PIN ("0601") that's easy to guess and
// was previously hardcoded in the shipped frontend bundle — so this is
// loud on purpose. Doesn't block startup (an admin lockout on a busy
// league night is worse than a weak default for now), but should be fixed.
if (!process.env.ADMIN_PIN) {
  logger.warn("ADMIN_PIN env var is not set — admin access is falling back to the default PIN. Set a real ADMIN_PIN in Render's environment settings.");
}

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) { return { id: req.id, method: req.method, url: req.url?.split("?")[0] }; },
      res(res) { return { statusCode: res.statusCode }; },
    },
  }),
);

// PERFORMANCE: Cache static assets in browser (prevents re-download)
// Mobile users benefit massively - no re-download on page reload
// Note: Gzip compression handled by Render reverse proxy (no external dependency)
app.use((req, res, next) => {
  // Cache static files for 1 year (use hash in filename for cache busting)
  if (req.url.match(/\.(js|css|png|jpg|gif|svg|woff|woff2|ttf|eot)$/i)) {
    res.set('Cache-Control', 'public, max-age=31536000, immutable');
    res.set('ETag', undefined); // Let browser use max-age, not ETag
  }
  // Cache API responses for 5 minutes for leaderboards/standings
  else if (req.url.match(/^\/api\/(standings|leaderboard)/)) {
    res.set('Cache-Control', 'public, max-age=300');
  }
  // Don't cache dynamic content
  else {
    res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
  }
  next();
});

app.set("trust proxy", 1);

app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));

const loginRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many login attempts — try again in 15 minutes" },
  skip: () => process.env.NODE_ENV !== "production",
});
app.use("/api/auth/login", loginRateLimit);

if (!process.env.SESSION_SECRET) {
  logger.error("SESSION_SECRET env var is not set — sessions will not work. Set it in Render/environment config.");
  process.exit(1);
}

const PgSession = connectPg(session);
app.use(session({
  store: new PgSession({
    conString: process.env.DATABASE_URL,
    tableName: "sessions",
    createTableIfMissing: false,
    // connect-pg-simple's default is a DELETE query every 15 minutes,
    // forever, regardless of real traffic — on a usage/compute-time-billed
    // database (e.g. Neon's free tier) that's a meaningful, entirely
    // avoidable source of the database being woken up when it would
    // otherwise be idle. Expired sessions are already functionally
    // harmless (the cookie's own maxAge + the store's own expiry check
    // reject them on lookup) — pruning them from the table just reclaims
    // storage, so there's no correctness reason to do it often. Once
    // every 6 hours is still 4x/day, plenty to keep the table tidy.
    pruneSessionInterval: 6 * 60 * 60,
  }),
  secret:            process.env.SESSION_SECRET!,
  resave:            false,
  saveUninitialized: false,
  name:              "tkdl.sid",
  cookie: {
    httpOnly: true,
    secure:   process.env.NODE_ENV === "production",
    maxAge:   30 * 24 * 60 * 60 * 1000,
    sameSite: process.env.NODE_ENV === "production" ? "strict" : "lax",
  },
}));

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// TEMPORARILY DISABLED: API response caching middleware - testing if it causes match submission to fail
// app.use("/api", cacheMiddleware());

// Repair legacy sessions that only have userId — backfill playerId + isAdmin
app.use(async (req, res, next) => {
  const s = req.session as any;
  if (s?.userId && (s.playerId == null || s.isAdmin == null)) {
    try {
      const [u] = await db.select({
        playerId: usersTable.playerId,
        isAdmin:  usersTable.isAdmin,
      }).from(usersTable).where(eq(usersTable.id, s.userId));
      if (u) {
        s.playerId = u.playerId;
        s.isAdmin  = u.isAdmin;
        req.session.save(() => {});
      }
    } catch { /* non-fatal */ }
  }
  next();
});

app.use("/api", router);

// In production, serve the built frontend and handle client-side routing
if (process.env.NODE_ENV === "production") {
  const frontendDist = process.env.FRONTEND_DIST
    ?? path.resolve(process.cwd(), "artifacts/tkdl/dist/public");
  app.use(express.static(frontendDist));
  app.get("/{*splat}", (_req, res) => {
    res.sendFile(path.join(frontendDist, "index.html"));
  });
}

async function seedRealData() {
  const [{ c }] = await db.select({ c: count() }).from(playersTable);
  if (Number(c) > 0) {
    logger.info("Players already seeded, skipping");
    return;
  }

  logger.info("Seeding real TKDL data...");

  // ── Seasons ────────────────────────────────────────────────────────────────
  const [feb] = await db.insert(seasonsTable).values({
    name: "February 2026",
    startDate: "2026-02-01",
    endDate:   "2026-02-28",
    isActive:  false,
    championName: "Sean",
    format: "301",
    totalMatches: 50,
  }).returning();

  const [may] = await db.insert(seasonsTable).values({
    name: "May 2026",
    startDate: "2026-05-01",
    endDate:   "2026-05-31",
    isActive:  false,
    championName: "Richard",
    totalMatches: 35,
  }).returning();

  const [june] = await db.insert(seasonsTable).values({
    name: "June 2026",
    startDate: "2026-06-01",
    isActive: true,
    totalMatches: 9,
  }).returning();

  // ── Players ─────────────────────────────────────────────────────────────────
  // Exact values from local DB as of June 6 2026 (9 June matches played)
  const playerData = [
    { name: "Graeme",           playerId: "P001", status: "ACTIVE",   points: 25, seasonWins: 0,  seasonLosses: 0,  seasonGamesPlayed: 0,  elo: 1052, careerWins: 16, careerLosses:  9, careerGamesPlayed: 25, careerPeakElo: 1119, peakPoints: 25, careerPoints:   46, currentWinStreak:  0, currentLossStreak: 1, longestWinStreak:  9, eliminationsCount: 0 },
    { name: "Sean",             playerId: "P002", status: "ACTIVE",   points: 49, seasonWins: 5,  seasonLosses: 0,  seasonGamesPlayed: 5,  elo: 1203, careerWins: 22, careerLosses:  3, careerGamesPlayed: 25, careerPeakElo: 1203, peakPoints: 49, careerPoints:   68, currentWinStreak: 13, currentLossStreak: 0, longestWinStreak: 13, eliminationsCount: 1 },
    { name: "Richard",          playerId: "P003", status: "ACTIVE",   points: 18, seasonWins: 1,  seasonLosses: 2,  seasonGamesPlayed: 3,  elo: 1071, careerWins: 16, careerLosses: 12, careerGamesPlayed: 28, careerPeakElo: 1094, peakPoints: 25, careerPoints:   52, currentWinStreak:  1, currentLossStreak: 0, longestWinStreak:  4, eliminationsCount: 0 },
    { name: "Ryan",             playerId: "P004", status: "ACTIVE",   points: 10, seasonWins: 1,  seasonLosses: 4,  seasonGamesPlayed: 5,  elo:  952, careerWins:  6, careerLosses: 14, careerGamesPlayed: 20, careerPeakElo: 1004, peakPoints: 25, careerPoints:  -40, currentWinStreak:  0, currentLossStreak: 2, longestWinStreak:  2, eliminationsCount: 0 },
    { name: "Robert",           playerId: "P005", status: "ACTIVE",   points: 26, seasonWins: 1,  seasonLosses: 1,  seasonGamesPlayed: 2,  elo: 1064, careerWins: 12, careerLosses:  5, careerGamesPlayed: 17, careerPeakElo: 1101, peakPoints: 26, careerPoints:   -5, currentWinStreak:  1, currentLossStreak: 0, longestWinStreak:  9, eliminationsCount: 1 },
    { name: "Cavan",            playerId: "P006", status: "ACTIVE",   points: 25, seasonWins: 0,  seasonLosses: 0,  seasonGamesPlayed: 0,  elo: 1035, careerWins:  9, careerLosses:  6, careerGamesPlayed: 15, careerPeakElo: 1085, peakPoints: 25, careerPoints:  -14, currentWinStreak:  0, currentLossStreak: 1, longestWinStreak:  7, eliminationsCount: 0 },
    { name: "Kyle",             playerId: "P007", status: "ACTIVE",   points: 23, seasonWins: 0,  seasonLosses: 1,  seasonGamesPlayed: 1,  elo:  916, careerWins:  2, careerLosses: 11, careerGamesPlayed: 13, careerPeakElo: 1000, peakPoints: 25, careerPoints:  -27, currentWinStreak:  0, currentLossStreak: 4, longestWinStreak:  2, eliminationsCount: 0 },
    { name: "Ronald Augustine", playerId: "P008", status: "ACTIVE",   points: 25, seasonWins: 0,  seasonLosses: 0,  seasonGamesPlayed: 0,  elo:  949, careerWins:  3, careerLosses:  9, careerGamesPlayed: 12, careerPeakElo: 1000, peakPoints: 35, careerPoints:  -25, currentWinStreak:  0, currentLossStreak: 3, longestWinStreak:  3, eliminationsCount: 0 },
    { name: "Jamie",            playerId: "P009", status: "ACTIVE",   points: 25, seasonWins: 0,  seasonLosses: 0,  seasonGamesPlayed: 0,  elo:  945, careerWins:  0, careerLosses:  2, careerGamesPlayed:  2, careerPeakElo: 1000, peakPoints: 25, careerPoints:  -25, currentWinStreak:  0, currentLossStreak: 2, longestWinStreak:  0, eliminationsCount: 0 },
    { name: "Cameron",          playerId: "P010", status: "ACTIVE",   points: 25, seasonWins: 0,  seasonLosses: 0,  seasonGamesPlayed: 0,  elo:  958, careerWins:  0, careerLosses:  3, careerGamesPlayed:  3, careerPeakElo: 1000, peakPoints: 25, careerPoints:  -25, currentWinStreak:  0, currentLossStreak: 3, longestWinStreak:  0, eliminationsCount: 0 },
    { name: "Aiden",            playerId: "P011", status: "INACTIVE", points:  0, seasonWins: 0,  seasonLosses: 0,  seasonGamesPlayed: 0,  elo: 1060, careerWins:  4, careerLosses:  0, careerGamesPlayed:  4, careerPeakElo: 1060, peakPoints:  0, careerPoints:  -25, currentWinStreak:  4, currentLossStreak: 0, longestWinStreak:  4, eliminationsCount: 0 },
    { name: "Brodie",           playerId: "P012", status: "INACTIVE", points:  0, seasonWins: 0,  seasonLosses: 0,  seasonGamesPlayed: 0,  elo:  921, careerWins:  0, careerLosses:  5, careerGamesPlayed:  5, careerPeakElo: 1000, peakPoints:  0, careerPoints:  -25, currentWinStreak:  0, currentLossStreak: 5, longestWinStreak:  0, eliminationsCount: 0 },
    { name: "Joanna",           playerId: "P013", status: "INACTIVE", points:  0, seasonWins: 0,  seasonLosses: 0,  seasonGamesPlayed: 0,  elo:  913, careerWins:  0, careerLosses:  6, careerGamesPlayed:  6, careerPeakElo: 1000, peakPoints:  0, careerPoints:  -25, currentWinStreak:  0, currentLossStreak: 6, longestWinStreak:  0, eliminationsCount: 0 },
    { name: "Roddie",           playerId: "P014", status: "INACTIVE", points:  0, seasonWins: 0,  seasonLosses: 0,  seasonGamesPlayed: 0,  elo:  920, careerWins:  0, careerLosses:  6, careerGamesPlayed:  6, careerPeakElo: 1000, peakPoints:  0, careerPoints:  -25, currentWinStreak:  0, currentLossStreak: 6, longestWinStreak:  0, eliminationsCount: 0 },
    { name: "Scott",            playerId: "P015", status: "ACTIVE",   points: 24, seasonWins: 1,  seasonLosses: 1,  seasonGamesPlayed: 2,  elo: 1041, careerWins:  4, careerLosses:  3, careerGamesPlayed:  7, careerPeakElo: 1058, peakPoints: 27, careerPoints:    2, currentWinStreak:  0, currentLossStreak: 1, longestWinStreak:  3, eliminationsCount: 0 },
  ];

  const insertedPlayers = await db.insert(playersTable).values(
    playerData.map(p => ({
      ...p,
      isActive: p.status !== "INACTIVE",
    }))
  ).returning();

  const byName      = new Map(insertedPlayers.map(p => [p.name, p]));
  const sean        = byName.get("Sean")!;
  const richard     = byName.get("Richard")!;
  const ryan        = byName.get("Ryan")!;
  const graeme      = byName.get("Graeme")!;
  const robert      = byName.get("Robert")!;
  const kyle        = byName.get("Kyle")!;
  const cameron     = byName.get("Cameron")!;
  const ronald      = byName.get("Ronald Augustine")!;
  const jamie       = byName.get("Jamie")!;
  const cavan       = byName.get("Cavan")!;
  const scott       = byName.get("Scott")!;

  // ── MAY_2026 matches (35 real wager matches from DB) ────────────────────────
  type MatchSeed = { w: typeof sean; l: typeof sean; stake: number; eloChange: number; gameType: string; playedAt: Date };
  const mayMatches: MatchSeed[] = [
    { w: ryan,    l: graeme,  stake:  3, eloChange: 20, gameType: "No black",                       playedAt: new Date("2026-05-13T11:51:31Z") },
    { w: richard, l: ryan,    stake:  3, eloChange: 17, gameType: "301 double in",                  playedAt: new Date("2026-05-14T17:49:24Z") },
    { w: richard, l: ryan,    stake:  3, eloChange: 15, gameType: "No point black",                 playedAt: new Date("2026-05-14T17:51:32Z") },
    { w: ryan,    l: cavan,   stake:  2, eloChange: 19, gameType: "Closest to bullseye",            playedAt: new Date("2026-05-15T10:29:30Z") },
    { w: graeme,  l: richard, stake:  3, eloChange: 14, gameType: "Bull finish",                    playedAt: new Date("2026-05-16T10:53:13Z") },
    { w: richard, l: ryan,    stake:  6, eloChange: 15, gameType: "Double or nothing 301",          playedAt: new Date("2026-05-16T11:11:59Z") },
    { w: ryan,    l: graeme,  stake:  5, eloChange: 20, gameType: "Pick a double",                  playedAt: new Date("2026-05-16T11:15:44Z") },
    { w: graeme,  l: richard, stake:  3, eloChange: 15, gameType: "Shanghai",                       playedAt: new Date("2026-05-17T10:15:50Z") },
    { w: richard, l: graeme,  stake:  3, eloChange: 19, gameType: "501",                            playedAt: new Date("2026-05-17T10:16:12Z") },
    { w: richard, l: sean,    stake:  4, eloChange: 19, gameType: "501 first to 3",                 playedAt: new Date("2026-05-18T11:46:18Z") },
    { w: sean,    l: ryan,    stake: 10, eloChange: 12, gameType: "301",                            playedAt: new Date("2026-05-19T11:16:26Z") },
    { w: sean,    l: richard, stake:  5, eloChange: 14, gameType: "301",                            playedAt: new Date("2026-05-20T12:18:01Z") },
    { w: sean,    l: ryan,    stake:  5, eloChange: 11, gameType: "Killer",                         playedAt: new Date("2026-05-20T12:18:31Z") },
    { w: sean,    l: ryan,    stake:  8, eloChange: 10, gameType: "Bull finish",                    playedAt: new Date("2026-05-20T12:18:53Z") },
    { w: sean,    l: kyle,    stake:  5, eloChange:  8, gameType: "Cricket",                        playedAt: new Date("2026-05-21T04:53:53Z") },
    { w: sean,    l: graeme,  stake:  4, eloChange: 12, gameType: "Cricket",                        playedAt: new Date("2026-05-21T09:26:24Z") },
    { w: richard, l: graeme,  stake:  3, eloChange: 16, gameType: "1001",                           playedAt: new Date("2026-05-21T11:19:54Z") },
    { w: sean,    l: kyle,    stake:  5, eloChange:  7, gameType: "Killer",                         playedAt: new Date("2026-05-22T03:43:58Z") },
    { w: sean,    l: cavan,   stake:  6, eloChange: 10, gameType: "Treble finish",                  playedAt: new Date("2026-05-22T06:51:17Z") },
    { w: graeme,  l: cameron, stake:  5, eloChange: 15, gameType: "Cricket",                        playedAt: new Date("2026-05-23T04:22:45Z") },
    { w: kyle,    l: jamie,   stake: 10, eloChange: 20, gameType: "Cricket",                        playedAt: new Date("2026-05-24T04:22:45Z") },
    { w: kyle,    l: jamie,   stake: 15, eloChange: 18, gameType: "Around the World",               playedAt: new Date("2026-05-24T04:25:45Z") },
    { w: richard, l: kyle,    stake:  5, eloChange: 12, gameType: "Around the world",               playedAt: new Date("2026-05-24T05:52:15Z") },
    { w: cavan,   l: richard, stake: 10, eloChange: 18, gameType: "Treble out",                     playedAt: new Date("2026-05-24T11:51:56Z") },
    { w: cavan,   l: richard, stake: 10, eloChange: 16, gameType: "Treble out (Double or nothing)", playedAt: new Date("2026-05-24T11:52:54Z") },
    { w: richard, l: robert,  stake:  5, eloChange: 19, gameType: "501 double in double",           playedAt: new Date("2026-05-25T07:39:54Z") },
    { w: graeme,  l: cameron, stake: 10, eloChange: 14, gameType: "Cricket",                        playedAt: new Date("2026-05-26T07:03:41Z") },
    { w: graeme,  l: cameron, stake: 10, eloChange: 13, gameType: "Around the world",               playedAt: new Date("2026-05-26T07:04:00Z") },
    { w: robert,  l: graeme,  stake:  5, eloChange: 15, gameType: "501",                            playedAt: new Date("2026-05-26T07:04:17Z") },
    { w: richard, l: cavan,   stake: 26, eloChange: 16, gameType: "501 double in double out",       playedAt: new Date("2026-05-26T07:05:14Z") },
    { w: graeme,  l: ronald,  stake: 25, eloChange: 11, gameType: "Cricket (3 bull finish)",        playedAt: new Date("2026-05-29T09:00:48Z") },
    { w: robert,  l: kyle,    stake: 10, eloChange:  9, gameType: "301",                            playedAt: new Date("2026-05-30T04:07:54Z") },
    { w: graeme,  l: kyle,    stake: 25, eloChange: 11, gameType: "301",                            playedAt: new Date("2026-05-30T04:24:26Z") },
    { w: richard, l: robert,  stake: 20, eloChange: 18, gameType: "Cricket",                        playedAt: new Date("2026-05-31T06:36:54Z") },
    { w: richard, l: graeme,  stake: 12, eloChange: 16, gameType: "501",                            playedAt: new Date("2026-05-31T09:44:55Z") },
  ];

  for (const m of mayMatches) {
    await db.insert(matchesTable).values({
      seasonId:   may.id,
      winnerId:   m.w.id,
      loserId:    m.l.id,
      winnerName: m.w.name,
      loserName:  m.l.name,
      stake:      m.stake,
      eloChange:  m.eloChange,
      gameType:   m.gameType,
      playedAt:   m.playedAt,
    });
  }

  // ── JUNE_2026 matches (9 real matches from DB) ──────────────────────────────
  const juneMatches: MatchSeed[] = [
    { w: sean,    l: richard, stake: 7, eloChange: 13, gameType: "Round the world (trebles)", playedAt: new Date("2026-06-03T11:41:35Z") },
    { w: sean,    l: ryan,    stake: 7, eloChange:  7, gameType: "Cricket",                   playedAt: new Date("2026-06-03T11:43:05Z") },
    { w: sean,    l: ryan,    stake: 5, eloChange:  7, gameType: "301",                       playedAt: new Date("2026-06-03T11:43:24Z") },
    { w: ryan,    l: richard, stake: 5, eloChange: 22, gameType: "Cricket",                   playedAt: new Date("2026-06-03T11:55:00Z") },
    { w: richard, l: ryan,    stake: 5, eloChange: 12, gameType: "501",                       playedAt: new Date("2026-06-04T10:21:44Z") },
    { w: sean,    l: kyle,    stake: 2, eloChange:  6, gameType: "301",                       playedAt: new Date("2026-06-06T01:57:38Z") },
    { w: scott,   l: robert,  stake: 2, eloChange: 19, gameType: "Round the clock",           playedAt: new Date("2026-06-06T05:33:22Z") },
    { w: robert,  l: scott,   stake: 3, eloChange: 17, gameType: "Round the clock",           playedAt: new Date("2026-06-06T05:33:53Z") },
    { w: sean,    l: ryan,    stake: 3, eloChange:  7, gameType: "301",                       playedAt: new Date("2026-06-06T07:01:34Z") },
  ];

  for (const m of juneMatches) {
    await db.insert(matchesTable).values({
      seasonId:   june.id,
      winnerId:   m.w.id,
      loserId:    m.l.id,
      winnerName: m.w.name,
      loserName:  m.l.name,
      stake:      m.stake,
      eloChange:  m.eloChange,
      gameType:   m.gameType,
      playedAt:   m.playedAt,
    });
  }

  // ── FEB_2026 standings snapshot (301 round-robin, Sean champion via playoff) ─
  // Robert pos1, Graeme pos2, Sean pos3 in league table — Sean won playoff
  const febStandings = [
    { player: "Robert",           pos:  1, wins: 9, losses: 2, points: 0, elo: 1017, champ: false },
    { player: "Graeme",           pos:  2, wins: 9, losses: 2, points: 0, elo: 1010, champ: false },
    { player: "Sean",             pos:  3, wins: 9, losses: 2, points: 0, elo: 1036, champ: true  },
    { player: "Cavan",            pos:  4, wins: 7, losses: 3, points: 0, elo:  998, champ: false },
    { player: "Aiden",            pos:  5, wins: 4, losses: 0, points: 0, elo: 1000, champ: false },
    { player: "Richard",          pos:  6, wins: 4, losses: 5, points: 0, elo: 1000, champ: false },
    { player: "Scott",            pos:  7, wins: 3, losses: 2, points: 0, elo: 1000, champ: false },
    { player: "Ronald Augustine", pos:  8, wins: 3, losses: 8, points: 0, elo:  990, champ: false },
    { player: "Ryan",             pos:  9, wins: 2, losses: 4, points: 0, elo:  985, champ: false },
    { player: "Brodie",           pos: 10, wins: 0, losses: 5, points: 0, elo:  985, champ: false },
    { player: "Kyle",             pos: 11, wins: 0, losses: 5, points: 0, elo:  980, champ: false },
    { player: "Joanna",           pos: 12, wins: 0, losses: 6, points: 0, elo:  975, champ: false },
    { player: "Roddie",           pos: 13, wins: 0, losses: 6, points: 0, elo:  977, champ: false },
  ];
  for (const s of febStandings) {
    const p = byName.get(s.player);
    if (!p) continue;
    await db.insert(seasonStandingsTable).values({
      seasonId: feb.id, playerId: p.id,
      position: s.pos, wins: s.wins, losses: s.losses,
      points: s.points, elo: s.elo, isChampion: s.champ,
    });
  }
  await db.update(seasonsTable).set({ championId: sean.id, championName: "Sean" }).where(eq(seasonsTable.id, feb.id));

  // ── MAY_2026 standings snapshot (Richard champion, wager-based) ─────────────
  // Richard 11W-5L 84pts (started at 25, won big wagers)
  const mayStandings = [
    { player: "Richard",          pos:  1, wins: 11, losses:  5, points:  84, elo: 1094, champ: true  },
    { player: "Graeme",           pos:  2, wins:  8, losses:  6, points:  71, elo: 1052, champ: false },
    { player: "Sean",             pos:  3, wins:  8, losses:  1, points:  69, elo: 1090, champ: false },
    { player: "Scott",            pos:  4, wins:  0, losses:  0, points:  25, elo: 1000, champ: false },
    { player: "Robert",           pos:  5, wins:  2, losses:  2, points:  15, elo:  990, champ: false },
    { player: "Cavan",            pos:  6, wins:  2, losses:  3, points:  11, elo: 1035, champ: false },
    { player: "Ryan",             pos:  7, wins:  3, losses:  6, points:   0, elo:  960, champ: false },
    { player: "Kyle",             pos:  8, wins:  2, losses:  5, points:   0, elo:  965, champ: false },
    { player: "Cameron",          pos:  9, wins:  0, losses:  3, points:   0, elo:  955, champ: false },
    { player: "Ronald Augustine", pos: 10, wins:  0, losses:  1, points:   0, elo:  950, champ: false },
    { player: "Jamie",            pos: 11, wins:  0, losses:  2, points:   0, elo:  950, champ: false },
  ];
  for (const s of mayStandings) {
    const p = byName.get(s.player);
    if (!p) continue;
    await db.insert(seasonStandingsTable).values({
      seasonId: may.id, playerId: p.id,
      position: s.pos, wins: s.wins, losses: s.losses,
      points: s.points, elo: s.elo, isChampion: s.champ,
    });
  }
  await db.update(seasonsTable).set({ championId: richard.id, championName: "Richard" }).where(eq(seasonsTable.id, may.id));

  logger.info("Real TKDL data seeded successfully");
}

async function seedSettings() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
  // ON CONFLICT DO NOTHING — preserves any admin-set values
  await db.execute(sql`
    INSERT INTO settings (key, value) VALUES
      ('live_scorer_enabled',    'false'),
      ('community_enabled',      'false'),
      ('messaging_enabled',      'false'),
      ('notifications_enabled',  'false'),
      ('doubles_event_enabled',  'true'),
      ('dartboard_heatmap_enabled', 'false'),
      ('voice_callouts_enabled', 'false')
    ON CONFLICT (key) DO NOTHING
  `);
  logger.info("Settings defaults ensured");
}

async function seedCommunityTables() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS community_posts (
      id          SERIAL PRIMARY KEY,
      player_id   INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      content     TEXT NOT NULL DEFAULT '',
      photo_path  TEXT,
      post_type   TEXT NOT NULL DEFAULT 'manual',
      auto_meta   JSONB NOT NULL DEFAULT '{}',
      status      TEXT NOT NULL DEFAULT 'pending',
      approved_at TIMESTAMPTZ,
      created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  // Patch columns that may be missing from older deployments
  await db.execute(sql`ALTER TABLE community_posts ADD COLUMN IF NOT EXISTS content     TEXT        NOT NULL DEFAULT ''`);
  await db.execute(sql`ALTER TABLE community_posts ADD COLUMN IF NOT EXISTS photo_path  TEXT`);
  await db.execute(sql`ALTER TABLE community_posts ADD COLUMN IF NOT EXISTS post_type   TEXT        NOT NULL DEFAULT 'manual'`);
  await db.execute(sql`ALTER TABLE community_posts ADD COLUMN IF NOT EXISTS auto_meta   JSONB       NOT NULL DEFAULT '{}'`);
  await db.execute(sql`ALTER TABLE community_posts ADD COLUMN IF NOT EXISTS status      TEXT        NOT NULL DEFAULT 'pending'`);
  await db.execute(sql`ALTER TABLE community_posts ADD COLUMN IF NOT EXISTS approved_at TIMESTAMPTZ`);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS post_reactions (
      id         SERIAL PRIMARY KEY,
      post_id    INTEGER NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
      player_id  INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      emoji      TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(post_id, player_id, emoji)
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS post_comments (
      id         SERIAL PRIMARY KEY,
      post_id    INTEGER NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
      player_id  INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      content    TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS direct_messages (
      id          SERIAL PRIMARY KEY,
      sender_id   INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      receiver_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      content     TEXT,
      photo_path  TEXT,
      read_at     TIMESTAMPTZ,
      created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS notifications (
      id           SERIAL PRIMARY KEY,
      player_id    INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      type         TEXT NOT NULL,
      actor_id     INTEGER REFERENCES players(id) ON DELETE SET NULL,
      entity_id    INTEGER,
      entity_type  TEXT,
      message      TEXT NOT NULL,
      read_at      TIMESTAMPTZ,
      created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS push_subscriptions (
      id         SERIAL PRIMARY KEY,
      player_id  INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      endpoint   TEXT NOT NULL UNIQUE,
      p256dh     TEXT NOT NULL,
      auth       TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  // The `notifications` table above (message/actor_id/entity_id/entity_type/
  // read_at) is the one actually live in production and used by the DM/
  // community/mark-as-read routes. A later, separate effort
  // (lib/notificationsMigration.ts, services/notificationService.ts) built a
  // whole second notification pipeline — match-result/rank-change/threat-alert
  // pushes, admin announcements, open/click analytics — against a DIFFERENT
  // assumed shape (title/body/data/"read"/clicked) that was never actually
  // applied to this table, so every one of those inserts has been silently
  // failing (caught by try/catch, logged, never surfaced). Adding the missing
  // columns here — additive only, nothing existing is touched — makes that
  // whole already-written pipeline actually work for the first time.
  await db.execute(sql`ALTER TABLE notifications ADD COLUMN IF NOT EXISTS title TEXT`);
  await db.execute(sql`ALTER TABLE notifications ADD COLUMN IF NOT EXISTS body TEXT`);
  await db.execute(sql`ALTER TABLE notifications ADD COLUMN IF NOT EXISTS data JSONB`);
  await db.execute(sql`ALTER TABLE notifications ADD COLUMN IF NOT EXISTS "read" BOOLEAN NOT NULL DEFAULT false`);
  await db.execute(sql`ALTER TABLE notifications ADD COLUMN IF NOT EXISTS clicked BOOLEAN NOT NULL DEFAULT false`);
  logger.info("Community tables ready");
}

async function seedGameTypes() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS game_types (
      id SERIAL PRIMARY KEY,
      key TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      engine TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'competitive',
      description TEXT DEFAULT '',
      config TEXT NOT NULL DEFAULT '{}',
      enabled BOOLEAN NOT NULL DEFAULT true,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
  type GT = typeof gameTypesTable.$inferInsert;
  const defaults: GT[] = [
    // ── Competitive — X01 ──────────────────────────────────────────────────
    { key: "501_double_out",       name: "501 – Double Out",         engine: "X01",         category: "competitive", description: "Standard PDC format. Must finish on a double.",                           config: JSON.stringify({ startingScore: 501,  doubleIn: false, doubleOut: true,  trebleOut: false }),              enabled: true, sortOrder: 1  },
    { key: "501_straight_out",     name: "501 – Straight Out",       engine: "X01",         category: "competitive", description: "No double required to finish.",                                           config: JSON.stringify({ startingScore: 501,  doubleIn: false, doubleOut: false, trebleOut: false }),              enabled: true, sortOrder: 2  },
    { key: "501_double_in",        name: "501 – Double In/Out",      engine: "X01",         category: "competitive", description: "Must start AND finish on a double.",                                      config: JSON.stringify({ startingScore: 501,  doubleIn: true,  doubleOut: true,  trebleOut: false }),              enabled: true, sortOrder: 3  },
    { key: "501_treble_out",       name: "501 – Treble Out",         engine: "X01",         category: "competitive", description: "Must finish on a treble. No bull finish.",                                config: JSON.stringify({ startingScore: 501,  doubleIn: false, doubleOut: false, trebleOut: true  }),              enabled: true, sortOrder: 4  },
    { key: "501_master_out",       name: "501 – Master Out",         engine: "X01",         category: "competitive", description: "Finish on any double or treble.",                                         config: JSON.stringify({ startingScore: 501,  doubleIn: false, masterOut: true                    }),              enabled: true, sortOrder: 5  },
    { key: "301_double_out",       name: "301 – Double Out",         engine: "X01",         category: "competitive", description: "Shorter format, double to finish.",                                       config: JSON.stringify({ startingScore: 301,  doubleIn: false, doubleOut: true,  trebleOut: false }),              enabled: true, sortOrder: 6  },
    { key: "301_double_in",        name: "301 – Double In/Out",      engine: "X01",         category: "competitive", description: "Must start AND finish on a double.",                                      config: JSON.stringify({ startingScore: 301,  doubleIn: true,  doubleOut: true,  trebleOut: false }),              enabled: true, sortOrder: 7  },
    { key: "1001_double_out",      name: "1001 – Double Out",        engine: "X01",         category: "competitive", description: "Endurance format. Double to finish.",                                     config: JSON.stringify({ startingScore: 1001, doubleIn: false, doubleOut: true                   }),              enabled: true, sortOrder: 8  },
    { key: "cricket",              name: "Cricket",                  engine: "Cricket",     category: "competitive", description: "Close 15–20 and bull. Score when opponent hasn't closed.",                config: JSON.stringify({ cutThroat: false, includesBull: true }),                                                 enabled: true, sortOrder: 9  },
    { key: "cutthroat_cricket",    name: "Cut-Throat Cricket",       engine: "Cricket",     category: "competitive", description: "Scoring points hurts opponents instead of helping you.",                  config: JSON.stringify({ cutThroat: true,  includesBull: true }),                                                 enabled: true, sortOrder: 10 },
    // ── Practice — skill games ──────────────────────────────────────────────
    { key: "around_the_world",     name: "Around the World",         engine: "Sequence",    category: "practice",    description: "Hit 1–20 in order, then bull to win.",                                    config: JSON.stringify({ type: "sequential", maxNumber: 20, includeBull: true  }),                               enabled: true, sortOrder: 11 },
    { key: "around_world_trebles", name: "Round the World (Trebles)",engine: "Sequence",    category: "practice",    description: "As above, but must hit the treble of each number.",                       config: JSON.stringify({ type: "sequential", maxNumber: 20, treblesOnly: true  }),                               enabled: true, sortOrder: 12 },
    { key: "round_the_clock",      name: "Round the Clock",          engine: "Sequence",    category: "practice",    description: "Hit 1–20 in order. No bull required.",                                    config: JSON.stringify({ type: "sequential", maxNumber: 20, includeBull: false }),                               enabled: true, sortOrder: 13 },
    { key: "shanghai",             name: "Shanghai",                 engine: "Sequence",    category: "practice",    description: "Rounds 1–7. Hit single, double, and treble of the round number to win.", config: JSON.stringify({ type: "shanghai", rounds: 7 }),                                                          enabled: true, sortOrder: 14 },
    { key: "halve_it",             name: "Halve-It",                 engine: "HalveIt",     category: "practice",    description: "Hit each target. Miss = your score halves. Highest score wins.",           config: JSON.stringify({ targets: [20, 16, "double", 17, "bull", 18, 19, "treble"] }),                            enabled: true, sortOrder: 15 },
    { key: "count_up",             name: "Count Up",                 engine: "CountUp",     category: "practice",    description: "Score as many points as possible. First to 501 wins.",                    config: JSON.stringify({ target: 501 }),                                                                          enabled: true, sortOrder: 16 },
    // ── Party / Fun ─────────────────────────────────────────────────────────
    { key: "killer",               name: "Killer",                   engine: "Killer",      category: "party",       description: "Hit your own double to become a Killer, then eliminate others.",           config: JSON.stringify({ lives: 3 }),                                                                             enabled: true, sortOrder: 17 },
    { key: "gotcha",               name: "Gotcha",                   engine: "Gotcha",      category: "party",       description: "Race to exactly 301. Hit opponent's score to reset them to zero.",         config: JSON.stringify({ target: 301 }),                                                                          enabled: true, sortOrder: 18 },
    { key: "no_black",             name: "No Black",                 engine: "Custom",      category: "party",       description: "TKDL special: any dart in the outer bull scores zero for that throw.",    config: JSON.stringify({ noOuterBull: true }),                                                                    enabled: true, sortOrder: 19 },
    { key: "bull_finish",          name: "Bull Finish",              engine: "X01",         category: "party",       description: "501 where you must finish on the bullseye (50) only.",                    config: JSON.stringify({ startingScore: 501, bullFinish: true }),                                                 enabled: true, sortOrder: 20 },
    { key: "nearest_bull",         name: "Nearest the Bull",         engine: "NearestBull", category: "party",       description: "Each player throws 3 darts. Closest to bull wins the round.",             config: JSON.stringify({ dartsEach: 3, rounds: 1 }),                                                              enabled: true, sortOrder: 21 },
    { key: "pick_a_double",        name: "Pick a Double",            engine: "Custom",      category: "party",       description: "TKDL custom: must call your double before throwing.",                      config: JSON.stringify({ callDouble: true }),                                                                     enabled: true, sortOrder: 22 },
    { key: "double_or_nothing",    name: "Double or Nothing",        engine: "X01",         category: "party",       description: "Play 301. If you miss your out-shot, the stake doubles.",                  config: JSON.stringify({ startingScore: 301, doubleOut: true, stakeDoubles: true }),                             enabled: true, sortOrder: 23 },

    // ── Competitive — Legs formats ───────────────────────────────────────────
    { key: "501_bo3",              name: "501 – Best of 3 Legs",     engine: "X01",         category: "competitive", description: "First to win 2 legs. PDC World Championship format.",                      config: JSON.stringify({ startingScore: 501, doubleIn: false, doubleOut: true, legs: 3 }),                       enabled: true, sortOrder: 24 },
    { key: "501_bo5",              name: "501 – Best of 5 Legs",     engine: "X01",         category: "competitive", description: "First to win 3 legs. Grand Prix / Matchplay format.",                      config: JSON.stringify({ startingScore: 501, doubleIn: false, doubleOut: true, legs: 5 }),                       enabled: true, sortOrder: 25 },
    { key: "501_bo7",              name: "501 – Best of 7 Legs",     engine: "X01",         category: "competitive", description: "First to win 4 legs. Players Championship format.",                        config: JSON.stringify({ startingScore: 501, doubleIn: false, doubleOut: true, legs: 7 }),                       enabled: true, sortOrder: 26 },
    { key: "301_bo3",              name: "301 – Best of 3 Legs",     engine: "X01",         category: "competitive", description: "Shorter game, first to 2 legs, double out.",                               config: JSON.stringify({ startingScore: 301, doubleIn: false, doubleOut: true, legs: 3 }),                       enabled: true, sortOrder: 27 },
    { key: "701_double_out",       name: "701 – Double Out",         engine: "X01",         category: "competitive", description: "Marathon singles format. Must finish on a double.",                         config: JSON.stringify({ startingScore: 701, doubleIn: false, doubleOut: true }),                               enabled: true, sortOrder: 28 },

    // ── Practice ─────────────────────────────────────────────────────────────
    { key: "bobs_27",              name: "Bob's 27",                 engine: "HalveIt",     category: "practice",    description: "Start with 27 points. Hit each double in order (1–20). Miss = subtract that double's value. Highest score wins.", config: JSON.stringify({ startingScore: 27, targets: "doubles", sequence: "1-20" }),                             enabled: true, sortOrder: 29 },
    { key: "bermuda_triangle",     name: "Bermuda Triangle",         engine: "Sequence",    category: "practice",    description: "Hit 12, 13, 14, Double Bull, 15, 16, 17, Triple Bull, 18, 19, 20, Bull in order. Miss costs you all darts that round.", config: JSON.stringify({ sequence: [12,13,14,"DB",15,16,17,"TB",18,19,20,"Bull"] }),                              enabled: true, sortOrder: 30 },
    { key: "round_the_board",      name: "Round the Board",          engine: "Sequence",    category: "practice",    description: "Hit 1 through 20 in order, then back from 20 to 1. First to finish wins.",  config: JSON.stringify({ sequence: "1-20-1", direction: "both" }),                                               enabled: true, sortOrder: 31 },
    { key: "high_score",           name: "High Score",               engine: "CountUp",     category: "practice",    description: "Each player throws 3 rounds of 3 darts. Most cumulative points wins.",      config: JSON.stringify({ rounds: 3, dartsPerRound: 3 }),                                                          enabled: true, sortOrder: 32 },
    { key: "doubles_challenge",    name: "Doubles Challenge",        engine: "Sequence",    category: "practice",    description: "Hit all 20 doubles in order then finish on double bull. Times each player.", config: JSON.stringify({ sequence: "doubles1-20+bull" }),                                                        enabled: true, sortOrder: 33 },

    // ── Party / Fun ─────────────────────────────────────────────────────────
    { key: "baseball",             name: "Baseball",                 engine: "Custom",      category: "party",       description: "9 innings. Each inning hit that inning's number — singles=1 run, doubles=2, trebles=3. Most runs wins.", config: JSON.stringify({ innings: 9, scoreDoubles: 2, scoreTrebles: 3 }),                                         enabled: true, sortOrder: 34 },
    { key: "scram",                name: "Scram",                    engine: "Custom",      category: "party",       description: "Two phases: Stopper closes numbers 20 down to 1. Scorer scores on open numbers. Swap halfway. Highest scorer wins.", config: JSON.stringify({ numbers: "20-1", phases: 2 }),                                                        enabled: true, sortOrder: 35 },
    { key: "legs",                 name: "Legs",                     engine: "Custom",      category: "party",       description: "Winner of each leg picks the starting score for the next leg (101–501). First to 3 legs wins.",  config: JSON.stringify({ minScore: 101, maxScore: 501, legsToWin: 3 }),                                          enabled: true, sortOrder: 36 },
    { key: "sudden_death",         name: "Sudden Death 501",         engine: "X01",         category: "party",       description: "Standard 501. Bust and you're reset to 50. No second chances.",             config: JSON.stringify({ startingScore: 501, doubleOut: false, bustResetTo: 50 }),                               enabled: true, sortOrder: 37 },
    { key: "football_darts",       name: "Football Darts",           engine: "Custom",      category: "party",       description: "TKDL custom: score 'goals' by hitting doubles. First to 5 goals wins. Hit a single = possession.", config: JSON.stringify({ goalsToWin: 5, goalZone: "doubles", possession: "singles" }),                            enabled: true, sortOrder: 38 },
    { key: "pairs_501",            name: "Pairs 501 (Teams)",        engine: "X01",         category: "party",       description: "2v2 team format. Teammates alternate throws. Double out. First team to 0 wins.", config: JSON.stringify({ startingScore: 501, doubleOut: true, teams: 2, playersPerTeam: 2 }),                   enabled: true, sortOrder: 39 },
    { key: "shanghai_sudden_death", name: "Shanghai (Sudden Death)",  engine: "Custom",      category: "party",       description: "7 rounds hitting 1 through 7. Hit a Shanghai (single+double+treble in one round) and you instantly win.", config: JSON.stringify({ rounds: 7, shanghaiWin: true }),                                                        enabled: true, sortOrder: 40 },
  ];

  // ── 22 new games — total 62 ───────────────────────────────────────────────
  const extra: GT[] = [
    { key: "golf_darts",           name: "Golf Darts (9 Holes)",      engine: "Custom",   category: "mini-games",  description: "9 holes targeting 1–9. Fewest darts to hit each target wins. Lowest total strokes wins.",          config: JSON.stringify({ holes: 9  }),                                                                            enabled: true, sortOrder: 41 },
    { key: "golf_darts_18",        name: "Golf Darts (18 Holes)",     engine: "Custom",   category: "mini-games",  description: "18-hole golf darts — targets 1–18. Longest format for serious players.",                          config: JSON.stringify({ holes: 18 }),                                                                            enabled: true, sortOrder: 42 },
    { key: "chase_the_dragon",     name: "Chase the Dragon",           engine: "Sequence", category: "practice",    description: "Hit T10→T11→...→T20, then D20→D19→...→D10, then finish on double bull.",                        config: JSON.stringify({ sequence: "chase_dragon" }),                                                             enabled: true, sortOrder: 43 },
    { key: "snooker_darts",        name: "Snooker Darts",             engine: "Custom",   category: "mini-games",  description: "Score like snooker: pot a red (15–20), then a colour (1–6). Reds=1pt, colours 2–7. 15 reds.",   config: JSON.stringify({ reds: 15, colours: [2,3,4,5,6,7] }),                                                     enabled: true, sortOrder: 44 },
    { key: "noughts_crosses",      name: "Noughts & Crosses",         engine: "Custom",   category: "mini-games",  description: "Claim numbers 1–9 in a 3×3 grid by hitting them. Three in a row wins — darts tic-tac-toe!",    config: JSON.stringify({ grid: [[1,2,3],[4,5,6],[7,8,9]] }),                                                      enabled: true, sortOrder: 45 },
    { key: "three_in_a_bed",       name: "Three-in-a-Bed",            engine: "Custom",   category: "mini-games",  description: "Call a treble segment, throw all 3 darts. All 3 in same treble bed = win. First to 5 rounds.",  config: JSON.stringify({ winsNeeded: 5 }),                                                                        enabled: true, sortOrder: 46 },
    { key: "bull_rush",            name: "Bull Rush",                 engine: "CountUp",  category: "mini-games",  description: "Race to 5 bull hits. Inner bull (50) or outer bull (25) both count. First to 5 wins.",          config: JSON.stringify({ target: 5, bullsOnly: true }),                                                           enabled: true, sortOrder: 47 },
    { key: "checkout_challenge",   name: "Checkout Challenge",        engine: "Custom",   category: "practice",    description: "Start at 170 (max checkout). Throw 3 darts — check out in one visit to win. Honour the double!", config: JSON.stringify({ startScore: 170, doubleOut: true }),                                                     enabled: true, sortOrder: 48 },
    { key: "fives",                name: "Fives",                     engine: "Custom",   category: "party",       description: "Each visit must score a multiple of 5 or score zero. Race to 51 points. Changes target strategy.", config: JSON.stringify({ target: 51, multiplier: 5 }),                                                           enabled: true, sortOrder: 49 },
    { key: "shanghai_20",          name: "Shanghai – 20 Rounds",      engine: "Sequence", category: "practice",    description: "20 rounds hitting numbers 1–20. Hit single+double+treble in one round for an instant win.",       config: JSON.stringify({ type: "shanghai", rounds: 20 }),                                                         enabled: true, sortOrder: 50 },
    { key: "round_clock_doubles",  name: "Round the Clock (Doubles)", engine: "Sequence", category: "practice",    description: "Hit the DOUBLE of each number 1–20 in order. Only the outer double ring counts. First to D20.",  config: JSON.stringify({ sequence: "doubles1-20" }),                                                              enabled: true, sortOrder: 51 },
    { key: "around_clock_quick",   name: "Around the Clock (Quick)",  engine: "Sequence", category: "practice",    description: "Race 1–20. A treble/double advances 2 numbers instead of 1. Fastest Around-the-World format.",   config: JSON.stringify({ type: "atw", quick: true }),                                                             enabled: true, sortOrder: 52 },
    { key: "killer_1_life",        name: "Sudden Death Killer",       engine: "Killer",   category: "party",       description: "Killer with 1 life only. Hit opponent's double ONCE and they're instantly eliminated. No mercy!", config: JSON.stringify({ lives: 1 }),                                                                             enabled: true, sortOrder: 53 },
    { key: "501_no_trebles",       name: "501 – No Treble Ring",      engine: "X01",      category: "party",       description: "501 Double Out but trebles don't count — darts landing in the treble ring score as singles only.", config: JSON.stringify({ startingScore: 501, doubleOut: true, noTrebles: true }),                                enabled: true, sortOrder: 54 },
    { key: "tactics",              name: "Tactics (Mickey Mouse)",    engine: "Cricket",  category: "competitive", description: "Cricket on numbers 10–20 and Bull — wider range adds more tactical depth.",                      config: JSON.stringify({ cutThroat: false, includesBull: true }),                                                 enabled: true, sortOrder: 55 },
    { key: "cricket_no_bull",      name: "Cricket – No Bull",         engine: "Cricket",  category: "competitive", description: "Standard Cricket but the bull is removed. Only 15–20 in play — six targets not seven.",          config: JSON.stringify({ cutThroat: false, includesBull: false }),                                               enabled: true, sortOrder: 56 },
    { key: "2001_double_out",      name: "2001 – Double Out",         engine: "X01",      category: "competitive", description: "Ultra-endurance: 2001 to start, double out to finish. The ultimate long-session challenge.",     config: JSON.stringify({ startingScore: 2001, doubleIn: false, doubleOut: true }),                                 enabled: true, sortOrder: 57 },
    { key: "701_bo3",              name: "701 – Best of 3 Legs",      engine: "X01",      category: "competitive", description: "Marathon best of 3 legs at 701 Double Out. Serious endurance test.",                            config: JSON.stringify({ startingScore: 701, doubleIn: false, doubleOut: true, legs: 3 }),                        enabled: true, sortOrder: 58 },
    { key: "accumulator",          name: "Accumulator",               engine: "CountUp",  category: "practice",    description: "Each visit must score MORE than the previous — or your total is halved. Forces consistent rounds.", config: JSON.stringify({ accumulate: true }),                                                                     enabled: true, sortOrder: 59 },
    { key: "high_score_9",         name: "Best of 9 Darts",           engine: "CountUp",  category: "practice",    description: "Exactly 9 darts each (3 visits). Highest total from those 9 darts wins. Pure scoring challenge.", config: JSON.stringify({ maxVisits: 3, dartsPerRound: 3 }),                                                       enabled: true, sortOrder: 60 },
    { key: "oche_roulette",        name: "Oche Roulette",             engine: "Custom",   category: "party",       description: "Random target called each round. Both must hit it in 3 darts. Miss = 0. Most pts after 9 rounds.", config: JSON.stringify({ rounds: 9, randomTarget: true }),                                                       enabled: true, sortOrder: 61 },
    { key: "one_eighty_challenge", name: "180 Challenge",             engine: "Custom",   category: "mini-games",  description: "Race to hit a perfect 180 (T20 T20 T20). First player to land one wins. 10 attempts each.",     config: JSON.stringify({ attempts: 10 }),                                                                         enabled: true, sortOrder: 62 },
    { key: "jdc_challenge_41",    name: "JDC Challenge 41",          engine: "JDCChallenge41",     category: "practice",    description: "3-phase challenge: Shanghai 10–15, Doubles 1–20+Bull (50pts each, Bull=100), Shanghai 15–20. Most points wins.", config: JSON.stringify({}),                                                                                enabled: true, sortOrder: 63 },
    { key: "exponential_bundle",  name: "Exponential Bundle",        engine: "ExponentialBundle",  category: "practice",    description: "Targets 7–12: 3 darts to hit the target (count hits), then 3 darts free scoring. Round score = hits × free score.", config: JSON.stringify({}),                                                                               enabled: true, sortOrder: 64 },
    { key: "shooting_gallery",    name: "Shooting Gallery",          engine: "ShootingGallery",    category: "practice",    description: "Checkout 121–130 in fewest darts (double out). Points: 3d=12, 4d=8, 5d=6, 6d=5, 7d=3, 8d=2, 9d=1. Fail=0.", config: JSON.stringify({}),                                                                                 enabled: true, sortOrder: 65 },
    { key: "dead_centre",         name: "Dead Centre (Kill Bull)",   engine: "DeadCentre",         category: "practice",    description: "Every dart must hit the bull (≥25). Miss = your score resets to 0. First to 300 wins.",           config: JSON.stringify({ target: 300 }),                                                                          enabled: true, sortOrder: 66 },
  ];

  // ── Team / Multi-player game types ──────────────────────────────────────────
  const teamGames: GT[] = [
    { key: "team_501_doubles",     name: "501 Doubles (2v2)",        engine: "TeamX01",     category: "team", description: "2v2 team 501. Teammates share a score and alternate throws. Double out.", config: JSON.stringify({ startingScore: 501, doubleOut: true,  teamSize: 2 }), enabled: true, sortOrder: 70 },
    { key: "team_301_doubles",     name: "301 Doubles (2v2)",        engine: "TeamX01",     category: "team", description: "2v2 team 301. Double out. Shorter team format.",                         config: JSON.stringify({ startingScore: 301, doubleOut: true,  teamSize: 2 }), enabled: true, sortOrder: 71 },
    { key: "team_501_triples",     name: "501 Triples (3v3)",        engine: "TeamX01",     category: "team", description: "3v3 team 501. Three-person teams share a score. Double out.",            config: JSON.stringify({ startingScore: 501, doubleOut: true,  teamSize: 3 }), enabled: true, sortOrder: 72 },
    { key: "team_cricket_doubles", name: "Cricket Doubles (2v2)",    engine: "TeamCricket", category: "team", description: "2v2 team Cricket. Teammates share marks and score. Close 15–20 and bull.", config: JSON.stringify({ cutThroat: false, teamSize: 2 }),                   enabled: true, sortOrder: 73 },
    { key: "team_cricket_triples", name: "Cricket Triples (3v3)",    engine: "TeamCricket", category: "team", description: "3v3 team Cricket. Three-person teams close the board together.",          config: JSON.stringify({ cutThroat: false, teamSize: 3 }),                   enabled: true, sortOrder: 74 },
    { key: "killer_3player",       name: "Killer — 3 Players",       engine: "MultiKiller", category: "team", description: "3-player Killer. Each picks a double, become a Killer, eliminate the others. Last standing wins.", config: JSON.stringify({ lives: 3, playerCount: 3 }), enabled: true, sortOrder: 75 },
    { key: "killer_4player",       name: "Killer — 4 Players",       engine: "MultiKiller", category: "team", description: "4-player Killer. Every player for themselves. Last standing wins.",       config: JSON.stringify({ lives: 3, playerCount: 4 }),                       enabled: true, sortOrder: 76 },
    { key: "killer_5player",       name: "Killer — 5 Players",       engine: "MultiKiller", category: "team", description: "5-player Killer free-for-all.",                                          config: JSON.stringify({ lives: 3, playerCount: 5 }),                       enabled: true, sortOrder: 77 },
    { key: "killer_6player",       name: "Killer — 6 Players",       engine: "MultiKiller", category: "team", description: "6-player Killer — full office mayhem.",                                  config: JSON.stringify({ lives: 3, playerCount: 6 }),                       enabled: true, sortOrder: 78 },
    { key: "team_501_straight",    name: "501 Doubles – Straight Out",engine: "TeamX01",     category: "team",     description: "2v2 team 501. No double required to finish. Great for beginners.",                                                                              config: JSON.stringify({ startingScore: 501, doubleOut: false, teamSize: 2 }),    enabled: true, sortOrder: 79 },
    { key: "99_darts_standard",    name: "99 Darts (Standard)",       engine: "NinetyNine",  category: "practice", description: "Throw 99 darts at your chosen target. S=1, D=2, T=3.",                                                                                         config: JSON.stringify({ variant: "standard" }),                                  enabled: true, sortOrder: 80 },
    { key: "99_darts_doubles",     name: "99 Darts (Doubles)",        engine: "NinetyNine",  category: "practice", description: "Throw 99 darts — only doubles on your chosen target count. Each hit = 1.",                                                                      config: JSON.stringify({ variant: "doubles" }),                                   enabled: true, sortOrder: 81 },
    { key: "99_darts_trebles",     name: "99 Darts (Trebles)",        engine: "NinetyNine",  category: "practice", description: "Throw 99 darts — only trebles on your chosen target count. Each hit = 1.",                                                                      config: JSON.stringify({ variant: "trebles" }),                                   enabled: true, sortOrder: 82 },
  ];

  await db.insert(gameTypesTable).values([...defaults, ...extra, ...teamGames]).onConflictDoNothing();

  // Add rules_text column if not present (safe to run every boot)
  await db.execute(sql`ALTER TABLE game_types ADD COLUMN IF NOT EXISTS rules_text TEXT`);

  logger.info(`Game types seeded (${defaults.length + extra.length + teamGames.length} declared, skipping existing)`);
}

// The `matches` table's DDL otherwise lives entirely in the Drizzle schema
// (applied via `drizzle-kit push`, a manual step) — but that step is easy to
// forget before a deploy, and Render's build/start commands never run it.
// These milestone-count columns follow the same self-healing ADD COLUMN IF
// NOT EXISTS pattern already used for practice_sessions/game_types/players
// above, so a normal git push + redeploy is enough on its own.
async function seedMatchesMilestoneColumns() {
  await db.execute(sql`ALTER TABLE matches ADD COLUMN IF NOT EXISTS winner_100s INTEGER`);
  await db.execute(sql`ALTER TABLE matches ADD COLUMN IF NOT EXISTS winner_140s INTEGER`);
  await db.execute(sql`ALTER TABLE matches ADD COLUMN IF NOT EXISTS winner_170s INTEGER`);
  await db.execute(sql`ALTER TABLE matches ADD COLUMN IF NOT EXISTS loser_100s  INTEGER`);
  await db.execute(sql`ALTER TABLE matches ADD COLUMN IF NOT EXISTS loser_140s  INTEGER`);
  await db.execute(sql`ALTER TABLE matches ADD COLUMN IF NOT EXISTS loser_170s  INTEGER`);
  logger.info("Matches milestone columns ready");
}

// Standalone table for the "favourite a card in my collection" feature on the
// account page — deliberately NOT the same thing as card_clash_favorites
// (which is per-game-mode equip-loadout favourites, keyed by the uuid
// card_definitions.card_id). This one just needs a simple per-player boolean
// against the small numeric ids used by the static COLLECTIBLE_CARDS list.
async function seedCardFavorites() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS card_favorites (
      player_id  INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      card_id    INTEGER NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY (player_id, card_id)
    )
  `);
  logger.info("Card favorites table ready");
}

// Boss Battle Mode: which bosses each player has beaten, so the ladder page
// knows what's unlocked. Pure arcade — never touches matches/Elo, so a
// simple per-player/boss row is all that's needed.
//
// boss_battle_stats is a separate table (not just extra columns on progress)
// because it needs a row from a player's very first ATTEMPT at a boss, win
// or lose — boss_battle_progress only ever gets a row once a boss is
// actually beaten, so it can't hold an attempts counter that should already
// be ticking up before the first win.
async function seedBossBattleProgress() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS boss_battle_progress (
      player_id   INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      boss_id     TEXT NOT NULL,
      defeated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY (player_id, boss_id)
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS boss_battle_stats (
      player_id    INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      boss_id      TEXT NOT NULL,
      attempts     INTEGER NOT NULL DEFAULT 0,
      wins         INTEGER NOT NULL DEFAULT 0,
      best_seconds INTEGER,
      PRIMARY KEY (player_id, boss_id)
    )
  `);
  logger.info("Boss battle progress + stats tables ready");
}

// Board Curse Mode: Solo mode's persistent state is two personal bests per
// player per game type — fewest visits to close out a single leg, and the
// longest Endless streak (legs survived back-to-back before stopping).
// Either can be null (a player may have one best but not the other yet).
async function seedBoardCurseBest() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS board_curse_best (
      player_id   INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      game_type   TEXT NOT NULL,
      best_visits INTEGER,
      best_streak INTEGER,
      updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY (player_id, game_type)
    )
  `);
  // Safe no-op if the table already has these — covers anyone who already
  // ran the earlier NOT NULL / no-streak version of this table locally.
  await db.execute(sql`ALTER TABLE board_curse_best ALTER COLUMN best_visits DROP NOT NULL`);
  await db.execute(sql`ALTER TABLE board_curse_best ADD COLUMN IF NOT EXISTS best_streak INTEGER`);
  logger.info("Board curse best table ready");
}

// Board Curse Mode: simple bragging-rights win/loss record vs Bot and vs
// Local Player, kept from the perspective of whoever's logged in on this
// device (Local's second "player" is just a typed name, not an account).
async function seedBoardCurseRecords() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS board_curse_records (
      player_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      format    TEXT NOT NULL,
      wins      INTEGER NOT NULL DEFAULT 0,
      losses    INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (player_id, format)
    )
  `);
  logger.info("Board curse records table ready");
}

// Backs drill-progress-service.ts, which was fully written (real mastery/
// trend queries) but never had its table created — nothing currently writes
// to it (no drill-runner UI calls POST .../drills/complete yet), so the
// drill progress / adaptive difficulty widgets will honestly show "no drills
// yet" until such a flow exists, rather than erroring.

// Doubles Event storage. These tables were never actually added to the boot
// sequence when the feature shipped (the original commit's own note said as
// much) — they only ever existed on Render because someone created them by
// hand directly against the production database, which is why a from-
// scratch boot (a fresh dev DB, a review app) throws "relation doubles_teams
// does not exist" the moment a season resets and tries to draw teams.
// IF NOT EXISTS makes this a no-op against that already-patched production
// database and a real fix everywhere else.
async function seedDoublesTables() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS doubles_teams (
      id            SERIAL PRIMARY KEY,
      season_id     INTEGER NOT NULL REFERENCES seasons(id) ON DELETE CASCADE,
      player1_id    INTEGER NOT NULL REFERENCES players(id),
      player2_id    INTEGER NOT NULL REFERENCES players(id),
      player3_id    INTEGER REFERENCES players(id),
      team_name     TEXT NOT NULL,
      points        INTEGER NOT NULL DEFAULT 50,
      peak_points   INTEGER NOT NULL DEFAULT 50,
      elo           INTEGER NOT NULL DEFAULT 1000,
      wins          INTEGER NOT NULL DEFAULT 0,
      losses        INTEGER NOT NULL DEFAULT 0,
      is_eliminated BOOLEAN NOT NULL DEFAULT false,
      created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS doubles_matches (
      id             SERIAL PRIMARY KEY,
      season_id      INTEGER NOT NULL REFERENCES seasons(id) ON DELETE CASCADE,
      winner_team_id INTEGER NOT NULL REFERENCES doubles_teams(id) ON DELETE CASCADE,
      loser_team_id  INTEGER NOT NULL REFERENCES doubles_teams(id) ON DELETE CASCADE,
      stake          INTEGER NOT NULL,
      elo_change     INTEGER,
      game_type      TEXT,
      notes          TEXT,
      played_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  logger.info("Doubles Event tables ready");
}

// Shift Wars: 3 fixed department teams (Fresh, Twilight, Shift Leader) competing
// on the same points/wager mechanic as the Doubles Event, but with no random
// draw/reroll — the roster is a manual, admin-managed, permanent assignment
// (a player's own department), and admin can edit each team's starting points
// at any time. Points-only, no ELO — this is a simpler, standings-free ladder.
// Also runs as its own monthly league alongside singles: performSeasonReset()
// resets each team's points/peak/record back to starting_points every reset,
// same cadence as singles, but never touches the roster or team rows themselves.
async function seedShiftWars() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS shift_wars_teams (
      id         SERIAL PRIMARY KEY,
      name       TEXT NOT NULL UNIQUE,
      points     INTEGER NOT NULL DEFAULT 0,
      peak_points INTEGER NOT NULL DEFAULT 0,
      wins       INTEGER NOT NULL DEFAULT 0,
      losses     INTEGER NOT NULL DEFAULT 0,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS shift_wars_matches (
      id              SERIAL PRIMARY KEY,
      winner_team_id  INTEGER NOT NULL REFERENCES shift_wars_teams(id) ON DELETE CASCADE,
      loser_team_id   INTEGER NOT NULL REFERENCES shift_wars_teams(id) ON DELETE CASCADE,
      stake           INTEGER NOT NULL,
      game_type       TEXT,
      notes           TEXT,
      played_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  // Snapshot of each team's standing at the end of every monthly reset, taken
  // right before points/record are cleared for the new month — otherwise a
  // department's whole month would vanish with no record of who won it, unlike
  // Doubles Event (new rows per season) or singles (season_standings).
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS shift_wars_season_history (
      id          SERIAL PRIMARY KEY,
      season_id   INTEGER NOT NULL REFERENCES seasons(id) ON DELETE CASCADE,
      team_id     INTEGER NOT NULL REFERENCES shift_wars_teams(id) ON DELETE CASCADE,
      team_name   TEXT NOT NULL,
      points      INTEGER NOT NULL,
      wins        INTEGER NOT NULL,
      losses      INTEGER NOT NULL,
      is_champion BOOLEAN NOT NULL DEFAULT false,
      recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  // Which department team each player belongs to — nullable, admin-assigned,
  // and never auto-reshuffled (unlike Doubles Event's random draw).
  await db.execute(sql`ALTER TABLE players ADD COLUMN IF NOT EXISTS shift_wars_team_id INTEGER REFERENCES shift_wars_teams(id)`);

  // The baseline each team's points reset to at the start of every new season —
  // distinct from `points` (the live, currently-in-play value) so an admin can
  // still correct a team's live points mid-month without moving what next
  // month resets to. Backfilled from the live points the first time this column
  // appears, so an install that predates monthly resets gets a sane starting
  // value instead of 0; from then on it's only ever changed by an explicit
  // "starting points" edit in the admin panel.
  await db.execute(sql`ALTER TABLE shift_wars_teams ADD COLUMN IF NOT EXISTS starting_points INTEGER NOT NULL DEFAULT 0`);
  await db.execute(sql`UPDATE shift_wars_teams SET starting_points = points WHERE starting_points = 0`);

  // Seed the 3 teams once with their agreed starting points. ON CONFLICT DO
  // NOTHING so this never overwrites admin edits to points on a later restart —
  // it only ever creates a team the first time its name doesn't exist yet.
  await db.execute(sql`
    INSERT INTO shift_wars_teams (name, points, peak_points, starting_points) VALUES
      ('Team Fresh', 125, 125, 125),
      ('Team Twilight', 75, 75, 75),
      ('Team Shift Leader', 50, 50, 50)
    ON CONFLICT (name) DO NOTHING
  `);
  logger.info("Shift Wars tables ready");
}

async function seedDrillCompletions() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS drill_completions (
      id               SERIAL PRIMARY KEY,
      player_id        INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      drill_id         TEXT NOT NULL,
      drill_title      TEXT NOT NULL,
      completed_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      duration_minutes INTEGER,
      score            NUMERIC,
      notes            TEXT,
      difficulty       TEXT
    )
  `);
  logger.info("Drill completions table ready");
}

async function seedPractice() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS practice_sessions (
      id               SERIAL PRIMARY KEY,
      player1_id       INTEGER REFERENCES players(id) ON DELETE SET NULL,
      player2_id       INTEGER REFERENCES players(id) ON DELETE SET NULL,
      game_type_key    TEXT NOT NULL,
      game_type_name   TEXT NOT NULL,
      winner_idx       INTEGER,
      detail           TEXT,
      darts_thrown     INTEGER,
      duration_seconds INTEGER,
      session_data     JSONB,
      created_at       TIMESTAMPTZ DEFAULT NOW()
    )
  `);
  // Add columns introduced after initial table creation (safe to run every boot)
  await db.execute(sql`ALTER TABLE practice_sessions ADD COLUMN IF NOT EXISTS p1_darts              INTEGER`);
  await db.execute(sql`ALTER TABLE practice_sessions ADD COLUMN IF NOT EXISTS p1_score              INTEGER`);
  await db.execute(sql`ALTER TABLE practice_sessions ADD COLUMN IF NOT EXISTS p1_180s              INTEGER DEFAULT 0`);
  await db.execute(sql`ALTER TABLE practice_sessions ADD COLUMN IF NOT EXISTS p1_checkout_attempts  INTEGER DEFAULT 0`);
  await db.execute(sql`ALTER TABLE practice_sessions ADD COLUMN IF NOT EXISTS p1_checkout_hits      INTEGER DEFAULT 0`);
  // P2 stat columns — populated in human-vs-human sessions tracked via the live scorer
  await db.execute(sql`ALTER TABLE practice_sessions ADD COLUMN IF NOT EXISTS p2_darts              INTEGER`);
  await db.execute(sql`ALTER TABLE practice_sessions ADD COLUMN IF NOT EXISTS p2_score              INTEGER`);
  await db.execute(sql`ALTER TABLE practice_sessions ADD COLUMN IF NOT EXISTS p2_180s              INTEGER DEFAULT 0`);
  await db.execute(sql`ALTER TABLE practice_sessions ADD COLUMN IF NOT EXISTS p2_checkout_attempts  INTEGER DEFAULT 0`);
  await db.execute(sql`ALTER TABLE practice_sessions ADD COLUMN IF NOT EXISTS p2_checkout_hits      INTEGER DEFAULT 0`);
  logger.info("Practice sessions table ready");

  // Per-mode access flags on players (all default true so existing players get full access)
  await db.execute(sql`ALTER TABLE players ADD COLUMN IF NOT EXISTS practice_enabled  BOOLEAN NOT NULL DEFAULT true`);
  await db.execute(sql`ALTER TABLE players ADD COLUMN IF NOT EXISTS tour_enabled       BOOLEAN NOT NULL DEFAULT true`);
  await db.execute(sql`ALTER TABLE players ADD COLUMN IF NOT EXISTS m501_enabled       BOOLEAN NOT NULL DEFAULT true`);
  await db.execute(sql`ALTER TABLE players ADD COLUMN IF NOT EXISTS shadow_bot_enabled BOOLEAN NOT NULL DEFAULT true`);
  await db.execute(sql`ALTER TABLE players ADD COLUMN IF NOT EXISTS last_free_pack_claim_time TIMESTAMPTZ`);
}

async function seedMatchParticipants() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS match_participants (
      id          SERIAL PRIMARY KEY,
      match_id    INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
      player_id   INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      player_name TEXT NOT NULL,
      team        TEXT NOT NULL,
      position    INTEGER NOT NULL DEFAULT 0
    )
  `);
  await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_mp_match_id ON match_participants(match_id)`);
  logger.info("match_participants table ready");
}

async function seedMaster501() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS master501_progress (
      id            SERIAL PRIMARY KEY,
      player_id     INTEGER NOT NULL UNIQUE REFERENCES players(id) ON DELETE CASCADE,
      current_tier  INTEGER NOT NULL DEFAULT 1,
      current_round INTEGER NOT NULL DEFAULT 1,
      updated_at    TIMESTAMPTZ DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS master501_runs (
      id           SERIAL PRIMARY KEY,
      player_id    INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      tier         INTEGER NOT NULL,
      round        INTEGER NOT NULL,
      dart_limit   INTEGER NOT NULL,
      legs_format  INTEGER NOT NULL,
      legs_won     INTEGER NOT NULL DEFAULT 0,
      legs_lost    INTEGER NOT NULL DEFAULT 0,
      result       TEXT,
      started_at   TIMESTAMPTZ DEFAULT NOW(),
      completed_at TIMESTAMPTZ
    )
  `);
  logger.info("master501 tables ready");
}

async function seedShadowBotAchievements() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS shadow_bot_achievements (
      id              SERIAL PRIMARY KEY,
      player_id       INTEGER NOT NULL,
      achievement_key TEXT NOT NULL,
      unlocked_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      context         JSONB,
      UNIQUE(player_id, achievement_key)
    )
  `);
  logger.info("shadow_bot_achievements table ready");
}

async function seedPlayoffMatches() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS playoff_matches (
      id          SERIAL PRIMARY KEY,
      season_id   INTEGER NOT NULL REFERENCES seasons(id) ON DELETE CASCADE,
      player1_id  INTEGER NOT NULL REFERENCES players(id),
      player2_id  INTEGER NOT NULL REFERENCES players(id),
      winner_id   INTEGER REFERENCES players(id),
      round       TEXT NOT NULL DEFAULT 'final',
      game_type   TEXT NOT NULL DEFAULT '501',
      notes       TEXT,
      created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_playoff_matches_season ON playoff_matches(season_id)`);
  logger.info("playoff_matches table ready");
}

async function seedSessions() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS sessions (
      sid    VARCHAR      NOT NULL PRIMARY KEY,
      sess   JSON         NOT NULL,
      expire TIMESTAMP(6) NOT NULL
    )
  `);
  await db.execute(sql`CREATE INDEX IF NOT EXISTS "IDX_sessions_expire" ON sessions (expire)`);
  logger.info("Sessions table ready");
}

async function seedUsers() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS users (
      id            SERIAL PRIMARY KEY,
      username      TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      player_id     INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      is_admin      BOOLEAN NOT NULL DEFAULT false,
      last_login_at TIMESTAMPTZ,
      created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_users_player_id ON users(player_id)`);
  logger.info("Users table ready");

  // Bootstrap first admin if SETUP_ADMIN_PASSWORD is set and no users exist yet
  const setupPwd = process.env.SETUP_ADMIN_PASSWORD;
  if (setupPwd) {
    const existing = (await db.execute(sql`SELECT COUNT(*)::int AS c FROM users`)).rows[0] as { c: number };
    if (Number(existing.c) === 0) {
      const graemeRow = (await db.execute(sql`SELECT id FROM players WHERE LOWER(name) = 'graeme' LIMIT 1`)).rows[0] as { id: number } | undefined;
      if (graemeRow) {
        const hash = await bcrypt.hash(setupPwd, 12);
        await db.execute(sql`
          INSERT INTO users (username, password_hash, player_id, is_admin)
          VALUES ('graeme', ${hash}, ${graemeRow.id}, true)
          ON CONFLICT (username) DO NOTHING
        `);
        logger.info("Bootstrap admin account created for graeme");
      }
    }
  }
}

async function init() {
  try {
    await seedSettings();
    await initializeCardTables();
    await initializeFeatureFlags();
    await addTkdlLiveBroadcastTables();
    await seedBroadcastSettings();
    await seedCardDefinitions();
    await initializeFeaturedCardShopTables();
    
    // Initialize featured card shop - rotate featured cards daily
    try {
      const { rotateFeatureCards } = await import("./services/featured-card-shop-service");
      await rotateFeatureCards();
    } catch (err) {
      logger.warn({ err }, "Failed to initialize featured card shop (non-critical)");
    }
    
    await addDailyChallengeKeyColumn();
    await addLongestLossStreakColumn();
    await addCareerBiggestPointsFallColumn();
    await challengeService.seedDefaultChallenges();
    await challengeService.seedComprehensivePool();
    await seedNotificationTables();
    await initializeNotificationPreferences();
    await addFavoritesColumn();
    await addAchievementRewards();
    await addAchievementSeasonColumn();
    await createCardClashPlayerSettingsTable();
    await createCardClashFavoritesTable();
    
    // Add performance indexes (CRITICAL for query speed)
    await addPerformanceIndexes();
    
    await seedCommunityTables();
    await seedMatchesMilestoneColumns();
    await seedCardFavorites();
    await seedDrillCompletions();
    await seedBossBattleProgress();
    await seedBoardCurseBest();
    await seedBoardCurseRecords();
    await seedDoublesTables();
    await seedShiftWars();
    await seedPractice();
    await seedMaster501();
    await seedMatchParticipants();
    await seedShadowBotAchievements();
    await seedTourSystem();
    await seedGameTypes();
    await seedAchievements();
    await seedRealData();
    // Must run after seedDoublesTables/seedShiftWars/seedRealData: it gives
    // Doubles and Shift Wars their own season row (re-parenting Doubles'
    // current teams onto it) and needs both those tables and a real active
    // singles season to already exist.
    await addSeasonLeagueType();
    await maybeAutoResetLeagueSeasons();
    await seedPlayoffMatches();
    await maybeAutoResetLeagueSeasons();
    
    // Initialize scheduled systems
    initializeCoachTipsScheduler();
    initializeFeaturedCardScheduler();
    initializeSeasonResetScheduler();
    await seedSessions();
    await seedUsers();
    await seedTitles();
    void sweepAllPlayerTitles(); // grant any titles earned via existing achievements
    
    // Initialize Card Clash season auto-check
    try {
      const { checkAndEndSeasonIfNeeded } = await import("./services/card-clash-season-rewards");
      await checkAndEndSeasonIfNeeded();
    } catch (err) {
      logger.warn({ err }, "Card Clash season auto-check failed (non-blocking)");
    }
    
    logger.info("Startup init complete");
  } catch (err) {
    logger.error({ err }, "Startup init failed");
  }
}

export async function initApp() {
  try {
    await init();
  } catch (err) {
    logger.error({ err }, "Critical: Startup init failed");
    throw err;
  }
}

export default app;
