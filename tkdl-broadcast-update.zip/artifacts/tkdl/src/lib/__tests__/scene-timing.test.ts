import { test, describe } from "node:test";
import assert from "node:assert/strict";
import {
  nextPlayableSegmentIndex, scheduleDialogueTurns, segmentDurationMs,
  canInsertOverlayAt, filterUnseenOverlays, mergeOverlayQueue, popReadyOverlay,
  advancePlayerState, INITIAL_PLAYER_STATE,
} from "../../features/broadcast/scene-timing.ts";
import type { DialogueTurn, LiveOverlayItem, Segment } from "../../features/broadcast/types.ts";

function segment(id: string): Segment {
  return {
    id, type: "UPSET", leagueType: "singles", storyId: 1, importance: "major", scene: "desk",
    dialogue: [{ speaker: "A", text: "x", holdSeconds: 3 }], graphic: null, validityRules: [], estimatedSeconds: 3,
  };
}

function overlay(storyId: number, overlayClass: LiveOverlayItem["overlayClass"]): LiveOverlayItem {
  return { storyId, leagueType: "singles", storyType: "UPSET", subjectKeys: ["p1"], score: 80, overlayClass };
}

describe("nextPlayableSegmentIndex", () => {
  test("returns fromIndex when it is already playable", () => {
    const segments = [segment("slot-1"), segment("slot-2")];
    assert.equal(nextPlayableSegmentIndex(segments, new Set(), 0), 0);
  });

  test("skips invalidated segments", () => {
    const segments = [segment("slot-1"), segment("slot-2"), segment("slot-3")];
    assert.equal(nextPlayableSegmentIndex(segments, new Set(["slot-1", "slot-2"]), 0), 2);
  });

  test("returns -1 once the programme is exhausted", () => {
    const segments = [segment("slot-1")];
    assert.equal(nextPlayableSegmentIndex(segments, new Set(["slot-1"]), 0), -1);
  });
});

describe("scheduleDialogueTurns / segmentDurationMs", () => {
  const dialogue: DialogueTurn[] = [{ speaker: "A", text: "a", holdSeconds: 3 }, { speaker: "B", text: "b", holdSeconds: 4 }];

  test("turns lay out back to back with no gaps", () => {
    const schedule = scheduleDialogueTurns(dialogue);
    assert.deepEqual(schedule[0], { turnIndex: 0, turn: dialogue[0], startMs: 0, endMs: 3000 });
    assert.deepEqual(schedule[1], { turnIndex: 1, turn: dialogue[1], startMs: 3000, endMs: 7000 });
  });

  test("total duration is the sum of every turn's hold time", () => {
    assert.equal(segmentDurationMs(dialogue), 7000);
  });

  test("empty dialogue has zero duration and an empty schedule", () => {
    assert.deepEqual(scheduleDialogueTurns([]), []);
    assert.equal(segmentDurationMs([]), 0);
  });
});

describe("canInsertOverlayAt", () => {
  test("nothing may interrupt mid-turn", () => {
    assert.equal(canInsertOverlayAt("just_in", { kind: "mid_turn" }), false);
    assert.equal(canInsertOverlayAt("breaking", { kind: "mid_turn" }), false);
  });

  test("JUST_IN only fires at a segment boundary", () => {
    assert.equal(canInsertOverlayAt("just_in", { kind: "segment_boundary" }), true);
    assert.equal(canInsertOverlayAt("just_in", { kind: "turn_boundary" }), false);
  });

  test("BREAKING fires at either a turn or segment boundary", () => {
    assert.equal(canInsertOverlayAt("breaking", { kind: "turn_boundary" }), true);
    assert.equal(canInsertOverlayAt("breaking", { kind: "segment_boundary" }), true);
  });
});

describe("filterUnseenOverlays", () => {
  test("drops overlays whose storyId has already been seen", () => {
    const overlays = [overlay(1, "just_in"), overlay(2, "breaking")];
    const result = filterUnseenOverlays(overlays, new Set([1]));
    assert.deepEqual(result.map(o => o.storyId), [2]);
  });
});

describe("mergeOverlayQueue", () => {
  test("de-duplicates by storyId — a re-polled overlay is not queued twice", () => {
    const queue = mergeOverlayQueue([overlay(1, "just_in")], [overlay(1, "just_in"), overlay(2, "just_in")]);
    assert.deepEqual(queue.map(o => o.storyId), [1, 2]);
  });

  test("BREAKING queue-jumps ahead of an already-queued JUST_IN", () => {
    const queue = mergeOverlayQueue([overlay(1, "just_in")], [overlay(2, "breaking")]);
    assert.deepEqual(queue.map(o => [o.storyId, o.overlayClass]), [[2, "breaking"], [1, "just_in"]]);
  });

  test("same-class overlays keep their original relative order (stable sort)", () => {
    const queue = mergeOverlayQueue([], [overlay(1, "just_in"), overlay(2, "just_in"), overlay(3, "just_in")]);
    assert.deepEqual(queue.map(o => o.storyId), [1, 2, 3]);
  });
});

describe("popReadyOverlay", () => {
  test("returns null when nothing in the queue may play at this position", () => {
    const queue = [overlay(1, "just_in")];
    assert.equal(popReadyOverlay(queue, { kind: "mid_turn" }), null);
    assert.equal(popReadyOverlay(queue, { kind: "turn_boundary" }), null); // JUST_IN needs a full segment boundary
  });

  test("pops the first eligible overlay and leaves the rest untouched", () => {
    const queue = [overlay(1, "just_in"), overlay(2, "breaking")];
    // At a turn boundary only the BREAKING one (index 1) is eligible.
    const result = popReadyOverlay(queue, { kind: "turn_boundary" });
    assert.ok(result);
    assert.equal(result!.overlay.storyId, 2);
    assert.deepEqual(result!.remainingQueue.map(o => o.storyId), [1]);
  });
});

describe("advancePlayerState", () => {
  test("BOOT -> LOAD_EDITION -> PLAY_SEGMENT -> PLAY_DIALOGUE_TURN", () => {
    let state = INITIAL_PLAYER_STATE;
    state = advancePlayerState(state, { totalTurnsInCurrentSegment: 2, hasMorePlayableSegments: true });
    assert.equal(state.phase, "LOAD_EDITION");
    state = advancePlayerState(state, { totalTurnsInCurrentSegment: 2, hasMorePlayableSegments: true });
    assert.equal(state.phase, "PLAY_SEGMENT");
    state = advancePlayerState(state, { totalTurnsInCurrentSegment: 2, hasMorePlayableSegments: true });
    assert.deepEqual(state, { phase: "PLAY_DIALOGUE_TURN", segmentIndex: 0, turnIndex: 0 });
  });

  test("advances through every dialogue turn before transitioning", () => {
    let state: ReturnType<typeof advancePlayerState> = { phase: "PLAY_DIALOGUE_TURN", segmentIndex: 0, turnIndex: 0 };
    state = advancePlayerState(state, { totalTurnsInCurrentSegment: 2, hasMorePlayableSegments: true });
    assert.deepEqual(state, { phase: "PLAY_DIALOGUE_TURN", segmentIndex: 0, turnIndex: 1 });
    state = advancePlayerState(state, { totalTurnsInCurrentSegment: 2, hasMorePlayableSegments: true });
    assert.equal(state.phase, "TRANSITION");
  });

  test("TRANSITION advances to the next segment when more are playable", () => {
    const state = advancePlayerState({ phase: "TRANSITION", segmentIndex: 2, turnIndex: 1 }, { totalTurnsInCurrentSegment: 0, hasMorePlayableSegments: true });
    assert.deepEqual(state, { phase: "PLAY_SEGMENT", segmentIndex: 3, turnIndex: 0 });
  });

  test("TRANSITION loops back to LOAD_EDITION once the programme is exhausted", () => {
    const state = advancePlayerState({ phase: "TRANSITION", segmentIndex: 9, turnIndex: 1 }, { totalTurnsInCurrentSegment: 0, hasMorePlayableSegments: false });
    assert.deepEqual(state, { phase: "LOAD_EDITION", segmentIndex: 0, turnIndex: 0 });
  });

  test("LIVE_INSERT resumes exactly where it left off", () => {
    const state = advancePlayerState({ phase: "LIVE_INSERT", segmentIndex: 4, turnIndex: 2 }, { totalTurnsInCurrentSegment: 3, hasMorePlayableSegments: true });
    assert.deepEqual(state, { phase: "PLAY_SEGMENT", segmentIndex: 4, turnIndex: 2 });
  });
});
