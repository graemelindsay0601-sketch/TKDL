function rebuildCurrentSeasonV2(){

  const ss =
    SpreadsheetApp.openById(
      "1XMiRxT7W_OMmnaplaAKzdTWQngepIQFCfI3qJ1oVbwc"
    );

  const playersSheet =
    ss.getSheetByName("PLAYERS");

  const matchesSheet =
    ss.getSheetByName("FORM_SUBMISSIONS");

  const currentSeason =
    getCurrentSeason();

  const players =
    playersSheet
      .getDataRange()
      .getValues();

  const matches =
    matchesSheet
      .getDataRange()
      .getValues()
      .slice(1);

  /* =========================
     RESET SEASON STATS
  ========================= */

  for(let r = 1; r < players.length; r++){

    if(
      String(players[r][1] || "")
        .toUpperCase() === "INACTIVE"
    ){
      continue;
    }

    players[r][3] = 25;     // Current Points
    players[r][4] = 0;      // Games
    players[r][5] = 0;      // Wins
    players[r][6] = 0;      // Losses
    players[r][7] = 25;     // Highest Balance
    players[r][8] = 1000;   // Elo
    players[r][9] = "🥈 Silver";
    players[r][11] = currentSeason;

  }

  /* =========================
     NAME LOOKUP
  ========================= */

  const playerLookup = {};

  for(let r = 1; r < players.length; r++){

    playerLookup[
      String(players[r][0]).trim()
    ] = r;

  }

  /* =========================
     REPLAY CURRENT SEASON
  ========================= */

  matches.forEach(row => {

    const season =
      String(row[5] || "").trim();

    if(
      season !== currentSeason
    ){
      return;
    }

    const participants =
      String(row[1] || "");

    const winner =
      String(row[3] || "").trim();

    const stake =
      Number(row[2]) || 0;

    const parts =
      participants.split(" vs ");

    if(parts.length !== 2){
      return;
    }

    const p1 =
      parts[0].trim();

    const p2 =
      parts[1].trim();

    const loser =
      winner === p1
        ? p2
        : p1;

    const winnerRow =
      playerLookup[winner];

    const loserRow =
      playerLookup[loser];

    if(
      winnerRow == null ||
      loserRow == null
    ){
      return;
    }

    players[winnerRow][3] += stake;
    players[loserRow][3] =
      Math.max(
        0,
        players[loserRow][3] - stake
      );

    players[winnerRow][4]++;
    players[loserRow][4]++;

    players[winnerRow][5]++;
    players[loserRow][6]++;

    players[winnerRow][7] =
      Math.max(
        players[winnerRow][7],
        players[winnerRow][3]
      );

  });

  /* =========================
     REBUILD ELO
  ========================= */

  for(let r = 1; r < players.length; r++){

    const wins =
      Number(players[r][5]) || 0;

    const losses =
      Number(players[r][6]) || 0;

    const elo =

      Math.round(
        1000 +
        ((wins - losses) * 15)
      );

    players[r][8] = elo;

    players[r][9] =

      elo >= 1100
        ? "🥇 Gold"

      : elo >= 950
        ? "🥈 Silver"

      : "🥉 Bronze";

  }

  /* =========================
     WRITE BACK
  ========================= */

  playersSheet
    .getRange(
      1,
      1,
      players.length,
      players[0].length
    )
    .setValues(players);

  /* =========================
     REBUILD RANKS
  ========================= */

  rebuildLeaderboardV2();

  Logger.log(
    "CURRENT SEASON REBUILD COMPLETE"
  );

}